let numero = prompt('Digite um número:');
if (numero > 0){
    resultado = numero * 7;
}