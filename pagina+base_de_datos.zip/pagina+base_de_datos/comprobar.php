<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <?php 
    $usuario = "root";
    $password = "";
    $servidor = "localhost";
    $basededatos = "db_registros";
    
    $conexion = mysqli_connect($servidor, $usuario, "");
    $db = mysqli_select_db($conexion, $basededatos);
     if($_SESSION['numeroaleatorio'] != $_REQUEST['numero']){
        echo"<a href='iniciarsesion.php'>Ingreso un valor incorrecto</a>";
     }else if (!empty($_POST['btnIngresar'])) {
        if (empty($_POST['usuarios']) and empty($_POST['contraseña'])) {
            echo 'Los Campos estan vacios';
        } else {
            $usuarios = $_POST['usuarios'];
            $contraseña = $_POST['contraseña'];
            $sql = $conexion->query("select * from valores where usuarios='$usuarios' and contraseña='$contraseña'");
            
            if ($datos = $sql->fetch_object()) {
                echo"Bien, datos comprobados correctamente <br><a href='principal.html'>volver</a>";
            }else{
                echo '<div>ACCESO DENEGADO</div>';
            }
        }
    }
    ?>
</body>
</html>