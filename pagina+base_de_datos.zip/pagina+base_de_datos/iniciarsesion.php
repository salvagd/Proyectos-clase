<!DOCTYPE html>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="decoracion.css"> 
    </head>
    <body>
        <form action="comprobar.php" method="POST">
        <div id="fondo2">
        <center>
             <label for="usuarios" >Usuario</label>
         </center>
         <center>
             <input type="text" name="usuarios" placeholder="usuario" required="">
         </center>
         <br><!--  -->
         <center>
        <label for="contraseña">Contraseña</label>
         </center><!-- comment -->
         <center>
             <input type="password" name="contraseña" placeholder="contraseña" required="">
         </center>
         <br><!--  -->
        <center>
         </form>
         <form action="pagina3.php" method"post">
    Digitos verificadores:<img src="pagina2.php">
    <br>
    Ingrese un valor:
    <input type="text" name="numero">
    <br>
    <input  type="submit"   name ="btnIngresar" value="Enviar">
 </form>   
    </center>
    </div>
    </body>
</html>