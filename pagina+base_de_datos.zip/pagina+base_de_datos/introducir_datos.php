<?php
$usuario = "root";
$password = "";
$servidor = "localhost";
$basededatos = "ejerciciocalvo";
$conexion = mysqli_connect($servidor, $usuario,"") or die ("Error con el servidor de la base de datos");
$db = mysqli_select_db($conexion, $basededatos);
$nombre=$_POST['nombre'];
$apellidos=$_POST['apellidos'];
$usuarios=$_POST['usuarios'];
$contraseña=$_POST['contraseña'];
$telefono=$_POST['telefono'];
$correo=$_POST['correo'];
$sql="INSERT INTO  valores VALUES('$nombre','$apellidos','$usuarios','$contraseña','$telefono','$correo')";
$ejecutar=mysqli_query($conexion, $sql);
if(!$ejecutar){
    echo"hubo un error";
}else{
    echo"Datos guardados correctamente!! <br><a href='principal.html'>Inicio</a>";
}
?>