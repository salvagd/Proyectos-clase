<?php

$usuario = "root";
$password = "";
$servidor = "localhost";
$basededatos = "valores";

$conexion = mysqli_connect($servidor, $usuario, "");
$db = mysqli_select_db($conexion, $basededatos);

if (!empty($_POST['btnIngresar'])) {
    if (empty($_POST['usuarios']) and empty($_POST['contraseña'])) {
        echo 'Los Campos estan vacios';
    } else {
        $usuarios = $_POST['usuarios'];
        $contraseña = $_POST['contraseña'];
        $sql = $conexion->query("select * from valores where usuarios='$usuarios' and contraseña='$contraseña'");
        
        if ($datos = $sql->fetch_object()) {
            header("joder.php");
        }else{
            echo '<div>ACCESO DENEGADO</div>';
        }
    }
}
?>