<?php
$matriz = array (
    "Pos1" =>array("A","B","C"),
    "Pos2" =>array("D","E","F"),
    "Pos3" =>array("G","H","I")
);
print($matriz["Pos1"][0]);
print($matriz["Pos1"][1]);
print($matriz["Pos1"][2]);
print("</br>");
print($matriz["Pos2"][0]);
print($matriz["Pos2"][1]);
print($matriz["Pos2"][2]);
print("</br>");
print($matriz["Pos3"][0]);
print($matriz["Pos3"][1]);
print($matriz["Pos3"][2]);
print("</br>");
?>