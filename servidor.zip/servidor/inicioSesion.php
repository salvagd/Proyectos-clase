<?php
$Usuario1=$_GET["usuario"];
if ($Usuario1=="userCorrecto"){
session_start(); // Se crea la sesión
$_SESSION["id"] = $Usuario1;
echo "Se ha creado una sesión con el nombre usuario: ".$_SESSION["id"]."<br>";
}else{
echo"No se puede iniciar una sesión con este usuario";
}
?>
