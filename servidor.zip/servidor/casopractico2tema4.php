<?php
$usuario=$_POST["login"];
$password=$_POST["password"];
validar($usuario, $password);
function validar($usuario, $password){
if ($usuario == "user1" ){
if ($password == "1234" ){
echo "Correcto, puedes pasar!";
}else{
echo "Contraseña incorrecta";
}
}else{
echo "Usuario incorrecto";
}
}
?>


