<?php
setcookie('cookie','valorCookie',time() +3600*24*31);
?>  