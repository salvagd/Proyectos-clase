<?php

$usuario = "root";
$password = "";
$servidor = "localhost";
$basededatos = "entorno_servidor";
$conexion = mysqli_connect($servidor, $usuario,"") or die ("Error con el servidor de la base de datos");
$db = mysqli_select_db($conexion, $basededatos);

if (!$conexion){ 
    die('Error de Conexión: ' . mysqli_connect_errno());    
}   

mysqli_set_charset($conexion, 'utf8');

$query = "SELECT * FROM alumnos";
$result = mysqli_query($conexion, $query);

if (mysqli_num_rows($result) > 0) {
    echo "
    <table>
    <tr>
    <th>Nombre</th>
    <th>Apellido</th>
    <th>DNI</th>
    </tr>";
    while($fila = mysqli_fetch_assoc($result)){
        echo"<tr>";
        echo  "<td>" . $fila["nombre"] . "</td>";
        echo "<td>". $fila["apellido"] . "</td>";
        echo  "<td>" .$fila["dni"]. "</td>";
        echo"</tr>";
    }  
    echo "</table>"; 
} else {
    die("Error: No hay datos en la tabla seleccionada");
}

mysqli_close($conexion);

?>