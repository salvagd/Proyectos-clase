<?php
$login = array(
   "Registro1" => array("Login:"," Rodavlas"," Salvador"),
   "Registro2" => array("Login:"," Samurai"," Luis David"),
   "Registro3" => array("Login:"," Yogurt"," Joel"),
   "Registro4" => array("Login:"," Boss"," Javi"),
);
print($login["Registro1"][0]);
print($login["Registro1"][1]);
print($login["Registro1"][2]);
print("</br>");
print($login["Registro2"][0]);
print($login["Registro2"][1]);
print($login["Registro2"][2]);
print("</br>");
print($login["Registro3"][0]);
print($login["Registro3"][1]);
print($login["Registro3"][2]);
print("</br>");
print($login["Registro4"][0]);
print($login["Registro4"][1]);
print($login["Registro4"][2]);
print("</br>");
echo date(DATE_RFC2822);// sentencia para poner la fecha de hoy con segundos y dicho formato
print("</br>");
echo rand(), "\n";//esta sentencia pasa por pantalla un valor aleatorio
echo rand(5,15),"\n";
print("</br>");
echo getcwd();//obtiene la ruta desde la que estas trabajando
 
function dialogar($saludo){
   return $saludo;
}
$saludo="Hola";
echo dialogar($saludo);
print("</br>");
function saludar($nombre,$apellido){
   echo "Hola $nombre $apellido";
}
$nombre = "\"Pepe\"";
$apellido = "\"Garcia\"";

saludar($nombre,$apellido);
print("</br>");
saludar($apellido,$nombre);
?>