<?php 

$libros = fopen('libros.txt', 'r+');

fclose($libros);

$numero = $_POST['numero'];
$titulo = $_POST['titulo'];
$autor = $_POST['autor'];

$libro = $numero . ',' . $titulo . ',' . $autor;


$libros = file('libros.txt');

$numeroBuscado = $_POST['numero'];

foreach ($libros as $i => $libro) {
    list($numero, $titulo, $autor) = explode(',', trim($libro));
    
    if ($numero == $numeroBuscado) {
        echo "<script>
        alert('Se ha añadido el libro $titulo');
        window.location.href = 'index.html';
        </script>";
        
        break;
    }
}

if (count($libros) >= 10) {
   
    echo "<script>
    alert('No puedes añadir más libros. Ya hay 10 libros en la lista.');
    window.location.href = 'inicio.html';
    </script>";
    exit;
}

// Si hay menos de 10 libros, añade el nuevo libro al final del archivo.
file_put_contents('libros.txt', $libro . PHP_EOL, FILE_APPEND);
//  10,La muerte de Artemio Cruz,Carlos Fuentes

?>