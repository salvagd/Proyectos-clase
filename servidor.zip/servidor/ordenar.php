<!DOCTYPE html>
<html>
<body>

<?php
 
//$numbers=array(4, 6, 2, 22, 11);
//arsort($numbers);

//foreach ($numbers as $key => $val) {
  //  echo "numbers[" . $key . "] = " . $val . "<br>";
//}
$cars = array("a", "BMW", "Aoyota","cc","bb");
$coches = ucwords('$cars');
sort($cars);


foreach ($cars as $key => $val) {
    echo "cars[" . $key . "] = " . $val . "<br>";
}
?>


</body>
</html>