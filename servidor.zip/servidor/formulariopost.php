<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="serv.php" method="post">
     nombre: <input type="text" name="nombre"></br>
     asunto: <input type="text" name="asunto"></br>
     mensaje: <input type="text" name="mensaje"></br>
     <input type="submit" value="okay">
    </form>
</body>
</html>