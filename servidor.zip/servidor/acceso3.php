<?php
session_start();
//Se indica el tiempo de actividad (seg)
$tiempoInactivo = 10;
// Si existe un valor para la clave timeout, la sesión ha sido establecida y seprocede con el cálculo restante
if(isset($_SESSION["timeout"])){
//Se calcula el tiempo que ha transcurrido desde que se conectó
$sessionTTL = time()-$_SESSION["timeout"];
//Si el tiempo de inactividad supera al establecido se cierra la sesión y selanza un fichero PHP con un aviso
if($sessionTTL > $tiempoInactivo){
session_destroy();
header("Location: acceso1.php");
}
}
//Se almacena la hora exacta del inicio o creación de sesión
$_SESSION["timeout"] = time();
?>
