<?php
$numeroinicial=0;
while($numeroinicial<=10){
    echo $numeroinicial++;
    print("</br>");
}
?>
