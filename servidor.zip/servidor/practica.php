<?php
$var=1;
// Primer ejercicio
/*if($var!=0){
    echo "El valor es positivo"; //Si la variable es distinta de cero el sistema pasara por pantalla que el valor es positivo
}*/
// Segundo ejercicio
/*if($var==3){
    echo"El número de la variable es uno o menos"; // si la variable es menor que 1 el sistema dira que es 1 o menos 
}else{
    echo "El número de la variable es mayor de 1";// si la variable es mayor , el sitema te dira que es mayor que 1
}*/
//Tercer ejercicio
/*if($var<1){
    echo"Es menor que 1";// si la variable es menor que 1 el sistema dira que es menor de 1
}elseif($var>1){
echo"Es mayor a 1"; //si la variable es mayor , el sitema te dira que es mayor que 1
}else{
    echo"Es igual que 1";// si la variable es 1 eñ sistema te dira que la variable es 1
}*/
//Cuarto ejercicio
/*switch($var){
    case $var<1: // si la variable es menor que 1 el sistema dira que es menor de 1
        echo"La variable es menor que 1";
        break;
    case $var>1://si la variable es mayor , el sitema te dira que es mayor que 1
        echo"La variable es mayor que 1";
        break;
    default:// si la variable es 1 eñ sistema te dira que la variable es 1
      echo"La variable es 1";
}*/
//Ejercicio 5 comentar la variable principal para poder usar el codigo sin problemas
/*for($var=3;$var<=30;$var++){ // la variable tendra un valor de 3 predefinido, si la variable es menor o igual a treinta esta aumentará hasta llegar al valor 30
    if($var>30){// Una vez se llegue a que la variable sea 30, el sistema se detendrá y dejará de imprimir por pantalla
        break;
    }
    echo $var;
}*/
//Sexto ejercicio
/*while($var<10){ //mientras la variable sea menor a diez se imprimiran valores hasta que se llegue al valor de 1o
    echo $var++;
}*/
//Séptimo ejercicio
/*do{
    echo$var ++; // la variable aumentará 
}while($var!=15); //mientras que la variable se distinta de 15*/
//Octavo ejercicio
/*
<?php
$frutas = array("manzana", "banana", "cereza");

foreach ($frutas as $nombrefruta) {
    echo "Fruta: " . $nombrefruta;
    echo "</br>";
}
?>
*/
//Funciones
/*echo date(DATE_RFC2822);// sentencia para poner la fecha de hoy con segundos y dicho formato
print("</br>");
echo rand(), "\n";//esta sentencia pasa por pantalla un valor aleatorio
echo rand(5,15),"\n";
print("</br>");
echo getcwd();//obtiene la ruta desde la que estas trabajando
 */
?>