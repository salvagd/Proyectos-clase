<?php
for($i=0;$i<=50;$i++){ // con el for haremos que la acción se repita 50 veces en total
$num = rand(0,99);// creamos una variable llamada $num la cuál nos dará un valor aleatorio entre 0 y 99.
$array = array($num);// creamos el array con el valor $num
echo $num . "</br>";// imprimimos el valor $num
}
?>