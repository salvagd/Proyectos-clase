<?php
    $numeros = array();//creamos el array de números
    for ($i= 0; $i <= 33; $i++) {// en este for haremos que la acción se repita 33 veces en total
        $numeros[] = rand(0, 100);// le decimos que los números tienen que estar entre 0 y 100
    }

    foreach ($numeros as $numero) {// le decimos que por cada número nos lo imprima con un br para que  no salgan todos en una misma linea 
        echo $numero . "</br>";//imprimimos el número
    }

    $mayor = max($numeros);// con esta variable seleccionamos el valor más grande del array
    $menor = min($numeros);// con esta variable seleccionamos el valor más pequeño del array
    $media = array_sum($numeros) / count($numeros);// con esta variable sumamos todos los números que hay en array y lo dividimos entre 33 que es la cantidad de número que le hemos puesto al array 

    echo "El número mayor es: $mayor<br>";//imprimir el número mas grande de la lista anterior
    echo "El número menor es: $menor<br>";//imprimir el número más pequeño de la lista anterior
    echo "La media es: $media<br>";//imprimir la media de la lista anterior
?>