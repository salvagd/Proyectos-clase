<?php

// Obtener los valores del formulario
$numero = $_POST['numero'];
$titulo = $_POST['titulo'];
$autor = $_POST['autor'];
$accion = $_POST['accion'];

// Leer todos los libros del archivo
$libros = file('libros.txt', FILE_IGNORE_NEW_LINES);

switch ($accion) {
    case 'insertar':
        // Comprueba si ya hay 10 libros en el archivo.
        if (count($libros) >= 10) {
            // Si hay 10 o más libros, muestra un mensaje de error y termina el script.
            echo "<script>alert('No puedes añadir más libros. Ya hay 10 libros en la lista.'); window.location.href = 'index.html';</script>";
            exit;
        }

        // Comprueba si todos los campos están llenos
        if(empty($numero) || empty($titulo) || empty($autor)) {
            echo "<script>alert('Por favor, rellena todos los campos.'); window.location.href = 'index.html';</script>";
            exit;
        }

        // Construir una cadena con los datos del nuevo libro
        $nuevoLibro = $numero . ',' . $titulo . ',' . $autor . PHP_EOL;

        // Añadir el nuevo libro al final del archivo.
        file_put_contents('libros.txt', $nuevoLibro, FILE_APPEND);

        // Muestra un mensaje de alerta indicando que se ha añadido un nuevo libro.
        echo "<script>alert('Se ha añadido un nuevo libro.'); window.location.href = 'index.html';</script>";
        break;
    case 'buscar':
    case 'modificar':
        // Comprueba si al menos un campo está lleno
        if(empty($numero) && empty($titulo) && empty($autor)) {
            echo "<script>alert('Por favor, rellena al menos un campo.'); window.location.href = 'index.html';</script>";
            exit;
        }
        
        // Buscar o modificar un libro por número, título o autor
        foreach ($libros as &$libro) {
            list($num, $tit, $aut) = explode(',', $libro);
            if ($num == $numero || $tit == $titulo || $aut == $autor) {
                if ($accion == 'buscar') {
                    echo "Libro encontrado: Número: $num, Título: $tit, Autor: $aut";
                    exit;
                } else { // modificar
                    if (!empty($_POST['nuevo_numero'])) { 
                        // Si se proporcionó un nuevo número de libro, actualice el número de libro.
                        $num = $_POST['nuevo_numero']; 
                    }
                    if (!empty($_POST['nuevo_titulo'])) { 
                        // Si se proporcionó un nuevo título de libro, actualice el título del libro.
                        $tit = $_POST['nuevo_titulo']; 
                    }
                    if (!empty($_POST['nuevo_autor'])) { 
                        // Si se proporcionó un nuevo autor de libro, actualice el autor del libro.
                        $aut = $_POST['nuevo_autor']; 
                    }
                    
                    // Actualizar el libro en la lista de libros.
                    $libro = "$num,$tit,$aut";
                    
                    file_put_contents('libros.txt', implode(PHP_EOL, $libros));
                    
                    echo "Libro modificado.";
                    
                    exit;
                }
            }
        }
        
        echo "Libro no encontrado.";
        
        break;
    case 'eliminar':
        // Comprueba si todos los campos están llenos
        if(empty($numero) || empty($titulo) || empty($autor)) {
            echo "<script>alert('Por favor, rellena todos los campos.'); window.location.href = 'index.html';</script>";
            exit;
        }

        // Eliminar un libro por número, título o autor
        foreach ($libros as $i => $libro) {
            list($num, $tit, $aut) = explode(',', $libro);
            if ($num == $numero && $tit == $titulo && $aut == $autor) {
                unset($libros[$i]);
                file_put_contents('libros.txt', implode(PHP_EOL, $libros));
                echo "Libro eliminado.";
                exit;
            }
        }
        
        echo "Libro no encontrado.";
        
        break;
        case 'ordenar':
            // Ordenar los libros por número de libro o título
            usort($libros, function($a, $b) {
                list($numA, $titA) = explode(',', $a);
                list($numB, $titB) = explode(',', $b);
                
                // Ordenar por número de libro si los números de libro son diferentes, de lo contrario ordenar por título
                return $numA == $numB ? strcmp($titA, $titB) : $numA - $numB;
            });
            
            file_put_contents('libros.txt', implode(PHP_EOL, $libros));
            
            echo "Libros ordenados.";
            
            break;
        case 'contar':
            // Contar el número de libros en la biblioteca
            echo "Hay " . count($libros) . " libros en la biblioteca.";
            
            break;
}