<?php 
session_start();
echo "Sesion iniciada <br>";
$_SESSION["id"] = "Usuario1";
echo "Se ha creado una sesión con el nombre del usuario:".$_SESSION["id"]."<br>"
?>
<a href="acceso2.php">Pincha aqui</a>   
