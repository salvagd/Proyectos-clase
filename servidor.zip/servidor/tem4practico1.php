<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="tem4practico1.php" method="get">
        valor mínimo: <input type="text" name="valor_minimo"></br>
        valor maximo: <input type="text" name="valor_maximo"></br>
    
        <input type="submit" value="Ok">
    </form>
    <?php
    if($_GET['valor_minimo']!=null && $_GET['valor_maximo']!=null){
    $valorminimo=$_GET['valor_minimo'];
    $valormaximo=$_GET['valor_maximo'];
    minmax($valorminimo, $valormaximo);
    function minmax($valorminimo, $valormaximo){
        while ($valorminimo <= $valormaximo) { 
            echo $valorminimo . "<br/>";
              $valorminimo++;
        }
    }
    minmax($valorminimo, $valormaximo);
}
    ?>
</body>
</html>