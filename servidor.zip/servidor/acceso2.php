<?php
session_start();
echo"Bienvenido de nuevo".$_SESSION["id"];
?>