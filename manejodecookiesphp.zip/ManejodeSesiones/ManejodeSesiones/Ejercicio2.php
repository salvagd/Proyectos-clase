<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Juego del número secreto</title>
    <link rel="stylesheet" href="Estilos/Ejercicio2.css">
</head>

<body>
    <h4>Juego del número secreto</h4>
    <p>Ingresa un número entre 1-100</p>

    <form method="post">
        <input type="number" name="guess" min="1" max="100" required>
        <input type="submit" value="Adivinar"><br>
        <button class="cookie" onclick="crearCookie()">Crear Cookie</button>
        <button class="cookie" onclick="mostrarCookie()">Mostrar Cookie</button>
        <button class="cookie" onclick="eliminarCookie()">Eliminar Cookie</button>
        <div id="cookieData"></div>
        <br><br><br>
    </form>
</body>

</html>

<?php
session_start();// se inicia la sesión
if (!isset($_SESSION['start_time'])) {
    $_SESSION['start_time'] = time();
}
if (time() - $_SESSION['start_time'] > 20) {
    echo "Tiempo de actividad sobrepasado, el número secreto era: " . $_SESSION['secret_number'];
    session_destroy();// si el tiempo de actividad  es sobrepasado se borra la sesión
?>
    <form method="post">
        <input type="submit" name="restart" value="Reiniciar Juego"><!--Boton para Reiniciar el Juego -->
    </form>
<?php
} else {
    if (!isset($_SESSION['secret_number'])) {//Generamos el numero secreto 
        $_SESSION['secret_number'] = rand(1, 100);//el numero secreto se genera aleatoriamente entre 1 y 100
        $_SESSION['attempts'] = 0;//inicializamos el contador de intentos es de cero
    }
    if (isset($_POST['guess'])) {
        $_SESSION['attempts']++;// incrementamos el contador de intentos
        $guess = $_POST['guess'];
        if ($guess > $_SESSION['secret_number']) {//con el if le diremos al usuario si el numero que ha introducido es mayor o menor al numero secreto 
            echo "El número secreto es menor que " . $guess;
        } elseif ($guess < $_SESSION['secret_number']) {
            echo "El número secreto es mayor que " . $guess;
        } else {
            echo "¡Enhorabuena! Has adivinado el número secreto '" . $_SESSION['secret_number'] . "' en " . $_SESSION['attempts'] . " intentos.\n";
            session_destroy();// se destruye la sesión si se acierta
        }
    }
}
?>
<script>
    function crearCookie() {// con esta funcion creamos una cookie
        var nombreCookie = "miCookie"; // Nombre de la cookie
        var valorCookie = "valor";
        var tiempoDeVida = 30; // Tiempo de vida en días
        var dominioCookie = "localhost";//dominio
        var rutaCookie = "/";//Ruta de la cookie

        var fechaExpiracion = new Date();
        fechaExpiracion.setTime(fechaExpiracion.getTime() + (tiempoDeVida * 24 * 60 * 60 * 1000));//establecemos el tiempo de expiracion de la cookie

        // Configura la cookie en JavaScript con ruta y dominio
        document.cookie = nombreCookie + "=" + valorCookie + "; expires=" + fechaExpiracion.toUTCString() + "; path=" + rutaCookie + "; domain=" + dominioCookie;

        // Comprueba si la cookie se configuró correctamente
        if (document.cookie.includes(nombreCookie)) {
            var valor = valorCookie;
            var mensajeElement = document.getElementById("mensaje");
            alert("La cookie se ha creado correctamente");
        } else {
            console.log("La cookie no está configurada.");
        }
    }

    function mostrarCookie() {//muestra en una alerta el valor de la cookie y si sigue activa
        var nombreCookie = "miCookie"; // Nombre de la cookie
        var cookieValue = null;
        var tiempoDeVida = 30; // Tiempo de vida en días
        var dominioCookie = "localhost";
        var rutaCookie = "/";
        var cookies = document.cookie.split('; ');

        for (var i = 0; i < cookies.length; i++) {
            var cookie = cookies[i].split('=');
            if (cookie[0] === nombreCookie) {
                cookieValue = cookie[1];
                break;
            }
        }

        if (cookieValue) {
            alert("DATOS DE MI COOKIE \nNombre: " + nombreCookie + "\nValue: " + cookieValue + "\nTime: " + tiempoDeVida +
                "\nDomain: " + dominioCookie + "\nPath: " + rutaCookie);
        } else {
            alert("La cookie no se encontró o ha caducado.");
        }
    }

    function eliminarCookie() {//funcion para eliminar la cookie
        var cookieName = "miCookie"; // Nombre de la cookie
        document.cookie = cookieName + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
        alert("Cookie eliminada: " + cookieName);
    }
</script>