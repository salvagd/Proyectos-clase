<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manejo de Cookies</title>
    <link rel="stylesheet" href="Estilos/Ejercicio3.css">
</head>
<body>
    <form method="post">
        <button type="submit" name="crearCookie">Crear Cookie</button>
        <button type="submit" name="mostrarCookie">Mostrar Cookie</button>
        <button type="submit" name="eliminarCookie">Eliminar Cookie</button>
    </form>

    <div>
        <?php
        if (isset($_POST['crearCookie'])) {//creamos la cookie
            echo '<form method="post">';
            echo '    <label for="nombre">Nombre:</label>';
            echo '    <input type="text" name="nombre" id="nombre" required><br>';
            echo '    <label for="value">Valor:</label>';
            echo '    <input type="text" name="value" id="value" required><br>';
            echo '    <label for="time">Tiempo (segundos):</label>';
            echo '    <input type="text" name="time" id="time" required><br>';
            echo '    <label for="domain">Dominio:</label>';
            echo '    <input type="text" name="domain" id="domain"><br>';
            echo '    <label for="path">Ruta:</label>';
            echo '    <input type="text" name="path" id="path"><br>';
            echo '    <button type="submit" name="crearCookieFinal">Crear Cookie</button>';
            echo '</form>';
        }

        if (isset($_POST['mostrarCookie'])) {//mostramos la cookie
            echo '<form method="post">';
            echo '    <label for="nombre">Nombre:</label>';
            echo '    <input type="text" name="nombre" id="nombre" required><br>';
            echo '    <button type="submit" name="mostrarCookieFinal">Mostrar Cookie</button>';
            echo '</form>';
        }

        if (isset($_POST['eliminarCookie'])) {//eliminamos la cookie
            echo '<form method="post">';
            echo '    <label for="nombre">Nombre:</label>';
            echo '    <input type="text" name="nombre" id="nombre" required><br>';
            echo '    <button type="submit" name="eliminarCookieFinal">Eliminar Cookie</button>';
            echo '</form>';
        }

        if (isset($_POST['crearCookieFinal'])) {
            $nombreCookie = $_POST['nombre'];
            $valorCookie = $_POST['value'];
            $tiempoDeVida = $_POST['time'];
            $dominio = $_POST['domain'];
            $ruta = $_POST['path'];

            // Establecer la cookie y los valores adicionales
            setcookie($nombreCookie, $valorCookie, time() + $tiempoDeVida, $ruta, $dominio);
            setcookie($nombreCookie . '_time', $tiempoDeVida, time() + $tiempoDeVida, $ruta, $dominio);
            setcookie($nombreCookie . '_domain', $dominio, time() + $tiempoDeVida, $ruta, $dominio);
            setcookie($nombreCookie . '_path', $ruta, time() + $tiempoDeVida, $ruta, $dominio);

            echo "La cookie se ha creado correctamente";
        }

        if (isset($_POST['mostrarCookieFinal'])) {//mostramos los valores de la cookie 
            $nombreCookie = $_POST['nombre'];

            if (isset($_COOKIE[$nombreCookie])) {
                $cookieValue = $_COOKIE[$nombreCookie];
                $cookieTime = $_COOKIE[$nombreCookie . '_time'];
                $cookieDomain = $_COOKIE[$nombreCookie . '_domain'];
                $cookiePath = $_COOKIE[$nombreCookie . '_path'];

                echo "Nombre: $nombreCookie<br>";
                echo "Valor: $cookieValue<br>";
                echo "Tiempo de vida: $cookieTime segundos<br>";
                echo "Dominio: $cookieDomain<br>";
                echo "Ruta: $cookiePath";
            } else {
                echo "La cookie con ese nombre no existe.";
            }
        }

        if (isset($_POST['eliminarCookieFinal'])) {//Elminamos la cookie
            $nombreCookie = $_POST['nombre'];

            if (isset($_COOKIE[$nombreCookie])) {
                setcookie($nombreCookie, "", time() - 3600);
                setcookie($nombreCookie . '_time', "", time() - 3600);
                setcookie($nombreCookie . '_domain', "", time() - 3600);
                setcookie($nombreCookie . '_path', "", time() - 3600);
                echo "Cookie eliminada: $nombreCookie";
            } else {
                echo "La cookie con ese nombre no existe.";
            }
        }
        ?>
    </div>
</body>
</html>
