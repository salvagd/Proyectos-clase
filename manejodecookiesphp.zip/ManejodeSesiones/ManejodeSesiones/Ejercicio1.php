<?php
if (isset($_POST['reiniciar'])) {//Al pulsar el boton reiniciar se volveran a jugar 
    $numeroSecreto = rand(1, 100);//usamos la funcion rand para generar un numero aleatorio entre 1 y 100
    $intentos = 0;
    $tiempo = time();
} elseif (!isset($_POST['numeroSecreto'])) {
    $numeroSecreto = rand(1, 100);
    $intentos = 0;
    $tiempo = time();
} else {
    $numeroSecreto = $_POST['numeroSecreto'];
    $intentos = $_POST['intentos'];
    $tiempo = $_POST['tiempo'];
}

if (isset($_POST['numero'])) {
    $intentos++;//El numero de intentos se incrementa progresivamente

    if ((time() - $tiempo) > 20) {// Si el tiempo es supera los 20 segundos dejarás de tener intentos
        echo "Has superado el tiempo máximo de actividad. Tiempo consumido: " . (time() - $tiempo) . " segundos. El número era: " . $numeroSecreto;// Se mostrara el numero y el tiempo que tardó  el usuario en adivinarlo
    } else {
        $numero = $_POST['numero'];
        if ($numero > $numeroSecreto) {//establecemos la condicion de que si el numero es mayor que el numero secreto se muestra el mensaje del echo
            echo "El número secreto es menor.";
        } elseif ($numero < $numeroSecreto) {//establecemos la condicion de que si el numero es menor que el numero secreto se muestra el mensaje del echo
            echo "El número secreto es mayor.";
        } else {// Una vez acertado el numero se muestra el mensaje de acertado
            echo "¡Enhorabuena! Has adivinado el número secreto '" . $numeroSecreto . "' en " . $intentos . " intentos.";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="Estilos/Ejercicio1.css">
</head>

<body>
    <form method="post">
        <input type="hidden" name="numeroSecreto" value="<?php echo $numeroSecreto; ?>">
        <input type="hidden" name="intentos" value="<?php echo $intentos; ?>">
        <input type="hidden" name="tiempo" value="<?php echo $tiempo; ?>">
        <input type="number" name="numero" min="1" max="100">
        <input type="submit" value="Adivinar">
    </form>

    <form method="post">
        <input type="submit" name="reiniciar" value="Reiniciar Juego">
    </form>
</body>

</html>